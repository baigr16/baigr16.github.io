import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
import os
plt.rc('font', family='Times New Roman')
config = {
"font.size": 30,
"mathtext.fontset":'stix',
"font.serif": ['SimSun'],
}
rcParams.update(config) # Latex 字体设置
#-------------------------------------------------------
t1 = 1.0 
mu = 1.0
kn = 100  
T = 1E-10
k1 = np.linspace(-np.pi, np.pi, kn)
Klist = np.array([k1, k1])
Umax = 1.0
#-------------------------------------------------------
def SC(kx, ky, delta):
    Ham = np.zeros((2, 2))
    Ham[0, 0] = t1 * (np.cos(kx) + np.cos(ky)) - mu
    Ham[1, 1] = -t1 * (np.cos(kx) + np.cos(ky)) + mu
    Ham[0, 1] = delta
    Ham[1, 0] = np.conjugate(delta)
    return Ham
#-------------------------------------------------------
def fermi(energy):
    return 1 / (np.exp(energy / T) + 1)
#-------------------------------------------------------
def diagH(Ham):
    eva, evc = np.linalg.eigh(Ham)
    return eva, evc
#-------------------------------------------------------
#无法收敛就直接输出-1
def selfC(U, max_iter = 1000):
    delta = 1e-4
    diff = 1e-6
    diff_I = 1.01 * diff
    iter_count = 0  

    while diff_I > diff:
        # if iter_count >= max_iter: 
        #     return -1 

        new_delta = 0
        for ik0 in range(kn):
            for ik1 in range(kn):
                kx = k1[ik0]
                ky = k1[ik1]
                Ham = SC(kx, ky, delta)
                eva, evc = diagH(Ham)
                fermi_vals = fermi(eva)
                MF = evc @ np.diag(fermi_vals) @ evc.conj().T
                new_delta += MF[0, 1]
        
        new_delta = -U * new_delta / kn**2
        diff_I = np.abs(new_delta - delta)
        delta = new_delta
        iter_count += 1 

    return delta
#-------------------------------------------------------
# selfC(0.5)
U_values = np.linspace(0.0,Umax, 100)
delta_values = []
for U in U_values:
    delta_values.append(selfC(U))

plt.figure(figsize=(8, 8))
picname = "order-mu-" +  format(mu,".2f") + ".png"
# plt.plot(U_values, delta_values, marker='o', color='b',markersize = 4)
plt.scatter(U_values, delta_values,c = "b", s = 20)
# 设置 x 轴刻度在 1 到 10，步长为 2
# plt.xticks(ticks=range(0, Umax, 2))
# plt.hlines(-0.1,xmin=0,xmax = Umax,colors = "black",lw = 2,ls = "-.")
# plt.vlines(1,ymin=0,ymax=Umax/2.0,colors = "b",lw = 4,ls = "-.")
plt.xlim(0,Umax)
# plt.ylim(-0.1,Umax/2.0)
plt.xlabel(r"$U/t$")
plt.ylabel(r"$\Delta$")
plt.tick_params(direction = 'in' ,axis = 'x',width = 0,length = 10)
plt.tick_params(direction = 'in' ,axis = 'y',width = 0,length = 10)
plt.title(r"$\mu = $" + format(mu,".2f"))
ax = plt.gca()
ax.spines["bottom"].set_linewidth(1.5)
ax.spines["left"].set_linewidth(1.5) 
ax.spines["right"].set_linewidth(1.5)
ax.spines["top"].set_linewidth(1.5)
# 减少 x 和 y 轴上的刻度数量
ax.locator_params(axis='x', nbins = 5)  # x 轴最多显示 3 个刻度
ax.locator_params(axis='y', nbins = 5)  # y 轴最多显示 3 个刻度
# plt.grid(True)
# plt.show()
plt.savefig(picname, dpi = 100,bbox_inches = 'tight')
plt.close()