import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
import os
import matplotlib.gridspec as gridspec
plt.rc('font', family='Times New Roman')
config = {
"font.size": 30,
"mathtext.fontset":'stix',
"font.serif": ['SimSun'],
}
rcParams.update(config) # Latex 字体设置
#----------------------------------------------------------
def plot_order(mu):
    dataname = "delta-normal.dat"
    # dataname = "julia-order.dat"
    picname = os.path.splitext(dataname)[0] + "-mu-" + format(mu,".2f") + ".png"
    da = np.loadtxt(dataname) 
    plt.figure(figsize=(8, 8))
    Umax = np.max(da[:,0])
    plt.scatter(da[:,0],da[:,1], s = 20,c = "b")
    plt.xlabel(r"$U/t$")
    plt.ylabel(r"$\Delta$")
    plt.title(r"$\mu = $" + format(mu,".2f"))
    plt.xlim(0,Umax)
    plt.tick_params(direction = 'in' ,axis = 'x',width = 0,length = 10)
    plt.tick_params(direction = 'in' ,axis = 'y',width = 0,length = 10)
    # plt.axis('scaled')
    ax = plt.gca()
    ax.spines["bottom"].set_linewidth(1.5)
    ax.spines["left"].set_linewidth(1.5) 
    ax.spines["right"].set_linewidth(1.5)
    ax.spines["top"].set_linewidth(1.5)
    ax.locator_params(axis='x', nbins = 5)  # x 轴最多显示 3 个刻度
    ax.locator_params(axis='y', nbins = 5)  # y 轴最多显示 3 个刻度
    # plt.show()
    plt.savefig(picname, dpi = 100,bbox_inches = 'tight')
    plt.close()
#----------------------------------------------------------
def plot_order_compare(mu):
    da1 = "fortran-order.dat"
    da2 = "julia-order.dat"
    picname = "order-compare"
    da1 = np.loadtxt(da1) 
    da2 = np.loadtxt(da2) 
    plt.figure(figsize=(8, 8))
    Umax = np.max(da1[:,0])
    plt.scatter(da1[:,0],da1[:,1], s = 20,c = "b",label = "Fortran")   # Fortran
    plt.scatter(da2[:,0],da2[:,1], s = 20,c = "r",label = "Julia")   # Julia
    plt.xlabel(r"$U/t$")
    plt.ylabel(r"$\Delta$")
    plt.title(r"$\mu = $" + format(mu,".2f"))
    plt.xlim(0,Umax)
    plt.tick_params(direction = 'in' ,axis = 'x',width = 0,length = 10)
    plt.tick_params(direction = 'in' ,axis = 'y',width = 0,length = 10)
    plt.legend(loc='best', fontsize = 25, scatterpoints = 1, markerscale = 2)  # markerscale 调整点的大小
    # plt.axis('scaled')
    ax = plt.gca()
    ax.spines["bottom"].set_linewidth(1.5)
    ax.spines["left"].set_linewidth(1.5) 
    ax.spines["right"].set_linewidth(1.5)
    ax.spines["top"].set_linewidth(1.5)
    ax.locator_params(axis='x', nbins = 5)  # x 轴最多显示 3 个刻度
    ax.locator_params(axis='y', nbins = 5)  # y 轴最多显示 3 个刻度
    # plt.show()
    plt.savefig(picname, dpi = 100,bbox_inches = 'tight')
    plt.close()
#------------------------------------------------------------
if __name__=="__main__":
    # plot_order(1.0)
    plot_order_compare(1.0)