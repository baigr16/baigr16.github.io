#!/bin/bash
#SBATCH --job-name=VaspTest
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=32
#SBATCH --partition=normal


# load the environment
#. /public/home/yujunxi/intel/oneapi/setvars.sh
module load mpi/intelmpi/2021.3.0
mpiexec -np 32 python square-sc.py > out